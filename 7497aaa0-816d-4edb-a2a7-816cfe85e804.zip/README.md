# Ansys HFSS 3D Layout (packaging / interconnect EM) MCP

Per-product offline MCP server. See SKILL.md for usage.

* pip client: pyaedt
* top-level import: ansys.aedt
* kind: grpc
* env: ANSYS_ROOT
